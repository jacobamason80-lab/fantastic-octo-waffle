#!/usr/bin/env bash
set -euo pipefail

APP_NAME="linux-cyber-toolbox"
PKG_NAME="linux-cyber-toolbox"
VERSION="$(python3 -c 'import re; s=open("toolbox/version.py").read(); print(re.search(r"__version__\s*=\s*\"([^\"]+)\"", s).group(1))')"

DEB_STAGE="debian"
rm -rf "$DEB_STAGE"

mkdir -p "$DEB_STAGE/DEBIAN"
mkdir -p "$DEB_STAGE/usr/lib/$APP_NAME"
mkdir -p "$DEB_STAGE/usr/local/bin"
mkdir -p "$DEB_STAGE/usr/share/applications"
mkdir -p "$DEB_STAGE/usr/share/icons/hicolor/512x512/apps"

cat > "$DEB_STAGE/DEBIAN/control" <<EOF
Package: $PKG_NAME
Version: $VERSION
Section: utils
Priority: optional
Architecture: all
Maintainer: Jacob Mason <none>
Depends: python3 (>= 3.10)
Description: Defensive cyber utility kit for Linux (authorized use only).
 Includes network checks, web headers, hashing/verification, auth log triage, and hygiene snapshot + GUI.
EOF

cp -r toolbox "$DEB_STAGE/usr/lib/$APP_NAME/"
cp requirements.txt "$DEB_STAGE/usr/lib/$APP_NAME/"
cp assets/cyber-toolbox.desktop "$DEB_STAGE/usr/share/applications/cyber-toolbox.desktop"
cp assets/cyber-toolbox.png "$DEB_STAGE/usr/share/icons/hicolor/512x512/apps/cyber-toolbox.png"

cat > "$DEB_STAGE/usr/local/bin/toolbox" <<'EOF'
#!/usr/bin/env bash
set -e
APP_DIR="/usr/lib/linux-cyber-toolbox"
python3 -m venv "$APP_DIR/.venv" >/dev/null 2>&1 || true
# shellcheck disable=SC1091
source "$APP_DIR/.venv/bin/activate"
pip -q install --upgrade pip >/dev/null 2>&1
pip -q install -r "$APP_DIR/requirements.txt" >/dev/null 2>&1
python -m toolbox "$@"
EOF
chmod +x "$DEB_STAGE/usr/local/bin/toolbox"

cat > "$DEB_STAGE/usr/local/bin/cyber-toolbox" <<'EOF'
#!/usr/bin/env bash
set -e
APP_DIR="/usr/lib/linux-cyber-toolbox"
python3 -m venv "$APP_DIR/.venv" >/dev/null 2>&1 || true
# shellcheck disable=SC1091
source "$APP_DIR/.venv/bin/activate"
pip -q install --upgrade pip >/dev/null 2>&1
pip -q install -r "$APP_DIR/requirements.txt" >/dev/null 2>&1
python -m toolbox.gui_main
EOF
chmod +x "$DEB_STAGE/usr/local/bin/cyber-toolbox"

DEB_FILE="${PKG_NAME}_${VERSION}_all.deb"
dpkg-deb --build "$DEB_STAGE" "$DEB_FILE" >/dev/null
echo "Built: $DEB_FILE"
