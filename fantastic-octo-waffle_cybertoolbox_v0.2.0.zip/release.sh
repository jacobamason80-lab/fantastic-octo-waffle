#!/usr/bin/env bash
set -euo pipefail

APP_NAME="linux-cyber-toolbox"
PKG_NAME="linux-cyber-toolbox"
MAIN_BRANCH="main"

die() { echo "ERROR: $*" >&2; exit 1; }
need_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

need_cmd git
need_cmd python3
need_cmd dpkg-deb
need_cmd zip

BUMP="${1:-patch}"
[[ "$BUMP" == "patch" || "$BUMP" == "minor" || "$BUMP" == "major" ]] || die "Usage: ./release.sh [patch|minor|major]"

if [[ -n "$(git status --porcelain)" ]]; then
  die "Working tree not clean. Commit or stash changes first."
fi

OLD_VER="$(python3 -c 'import re; s=open("toolbox/version.py").read(); print(re.search(r"__version__\s*=\s*\"([^\"]+)\"", s).group(1))')"

python3 - <<PY
import re
old="${OLD_VER}"
major, minor, patch = map(int, old.split("."))
bump="${BUMP}"
if bump=="patch":
    patch += 1
elif bump=="minor":
    minor += 1; patch = 0
elif bump=="major":
    major += 1; minor = 0; patch = 0
new=f"{major}.{minor}.{patch}"
p="toolbox/version.py"
s=open(p,"r",encoding="utf-8").read()
s=re.sub(r'__version__\s*=\s*"[^"]+"', f'__version__ = "{new}"', s)
open(p,"w",encoding="utf-8").write(s)
print(new)
PY
NEW_VER="$(python3 -c 'import re; s=open("toolbox/version.py").read(); print(re.search(r"__version__\s*=\s*\"([^\"]+)\"", s).group(1))')"
TAG="v${NEW_VER}"

echo "[+] Building .deb..."
./build.sh >/dev/null
DEB_FILE="${PKG_NAME}_${NEW_VER}_all.deb"
[[ -f "$DEB_FILE" ]] || die "Deb not found: $DEB_FILE"

git add -A
git commit -m "Release ${TAG}"
git tag -a "${TAG}" -m "${TAG}"

REL_DIR="release_artifacts/${TAG}"
rm -rf "${REL_DIR}"
mkdir -p "${REL_DIR}"
cp -f "${DEB_FILE}" "${REL_DIR}/"
cp -f README.md LICENSE "${REL_DIR}/" || true

cat > "${REL_DIR}/RELEASE_NOTES.md" <<EOF
# ${TAG}

## Install (Linux Mint)
\`\`\`bash
sudo apt install ./${DEB_FILE}
\`\`\`

## Run
\`\`\`bash
toolbox --help
cyber-toolbox
\`\`\`
EOF

(cd release_artifacts && zip -qr "${TAG}.zip" "${TAG}")

echo
echo "Next:"
echo "  git push origin ${MAIN_BRANCH}"
echo "  git push origin ${TAG}"
echo "Then create a GitHub Release for ${TAG} and upload ${DEB_FILE} (or release_artifacts/${TAG}.zip)."
