from __future__ import annotations
from collections import Counter
from pathlib import Path
import re

FAILED_PATTERNS = [
    re.compile(r"Failed password for (?:invalid user )?(?P<user>\S+) from (?P<ip>\S+)"),
    re.compile(r"authentication failure.*rhost=(?P<ip>\S+).*user=(?P<user>\S*)"),
]

def triage_auth_log(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Log not found: {path}")

    ip_counter = Counter()
    user_counter = Counter()
    total_failed = 0

    for line in p.read_text(errors="ignore").splitlines():
        for pat in FAILED_PATTERNS:
            m = pat.search(line)
            if m:
                total_failed += 1
                ip = (m.groupdict().get("ip") or "").strip()
                user = (m.groupdict().get("user") or "").strip()
                if ip:
                    ip_counter[ip] += 1
                if user:
                    user_counter[user] += 1
                break

    return {
        "path": str(p),
        "total_failed_matches": total_failed,
        "top_ips": ip_counter.most_common(10),
        "top_users": user_counter.most_common(10),
    }
