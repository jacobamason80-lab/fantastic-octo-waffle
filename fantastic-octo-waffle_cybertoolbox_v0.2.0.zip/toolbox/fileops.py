from __future__ import annotations
import hashlib
from pathlib import Path

SUPPORTED = {"md5", "sha1", "sha256"}

def file_hash(path: str, algo: str = "sha256") -> str:
    algo = algo.lower().strip()
    if algo not in SUPPORTED:
        raise ValueError(f"Unsupported algo: {algo}. Use one of: {', '.join(sorted(SUPPORTED))}")
    h = hashlib.new(algo)
    p = Path(path)
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def verify_file_hash(path: str, expected: str, algo: str = "sha256") -> dict:
    actual = file_hash(path, algo=algo)
    ok = actual.lower() == expected.lower().strip()
    return {"ok": ok, "expected": expected, "actual": actual, "algo": algo}
