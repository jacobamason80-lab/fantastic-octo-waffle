from __future__ import annotations
import requests
from urllib.parse import urljoin

def fetch_headers(url: str, timeout: int = 10) -> dict:
    r = requests.get(url, timeout=timeout, allow_redirects=True)
    return {"final_url": r.url, "status": r.status_code, "headers": dict(r.headers)}

def discover_robots_and_sitemap(base_url: str, timeout: int = 10) -> dict:
    robots_url = urljoin(base_url.rstrip("/") + "/", "robots.txt")
    out = {"robots_url": robots_url, "robots_status": None, "sitemaps": [], "raw": ""}

    r = requests.get(robots_url, timeout=timeout, allow_redirects=True)
    out["robots_status"] = r.status_code
    if r.ok:
        out["raw"] = r.text[:5000]
        for line in r.text.splitlines():
            line = line.strip()
            if line.lower().startswith("sitemap:"):
                out["sitemaps"].append(line.split(":", 1)[1].strip())
    return out
