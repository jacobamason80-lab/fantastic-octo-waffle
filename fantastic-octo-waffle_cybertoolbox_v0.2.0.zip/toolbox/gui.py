from __future__ import annotations
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTextEdit, QTabWidget, QComboBox
)
from PySide6.QtCore import Qt

from .utils import parse_ports
from . import net, web, fileops, logs, hygiene
from .version import __version__

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"Cyber Toolbox v{__version__}")
        self.resize(980, 640)

        root = QVBoxLayout(self)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs)

        self.out = QTextEdit()
        self.out.setReadOnly(True)
        self.out.setStyleSheet("font-family: monospace;")
        root.addWidget(self.out, 1)

        self.tabs.addTab(self.tab_network(), "Network")
        self.tabs.addTab(self.tab_web(), "Web")
        self.tabs.addTab(self.tab_files(), "File")
        self.tabs.addTab(self.tab_logs(), "Logs")
        self.tabs.addTab(self.tab_hygiene(), "Hygiene")

    def log(self, text: str):
        self.out.append(text)

    def tab_network(self) -> QWidget:
        w = QWidget()
        l = QVBoxLayout(w)

        row1 = QHBoxLayout()
        self.net_host = QLineEdit("127.0.0.1")
        self.net_ports = QLineEdit("22,80,443")
        scan_btn = QPushButton("Scan")
        scan_btn.clicked.connect(self.do_scan)

        row1.addWidget(QLabel("Host:"))
        row1.addWidget(self.net_host, 2)
        row1.addWidget(QLabel("Ports:"))
        row1.addWidget(self.net_ports, 2)
        row1.addWidget(scan_btn)
        l.addLayout(row1)

        row2 = QHBoxLayout()
        self.dns_name = QLineEdit("example.com")
        dns_btn = QPushButton("DNS Lookup")
        dns_btn.clicked.connect(self.do_dns)
        self.rdns_ip = QLineEdit("8.8.8.8")
        rdns_btn = QPushButton("Reverse DNS")
        rdns_btn.clicked.connect(self.do_rdns)

        row2.addWidget(QLabel("DNS:"))
        row2.addWidget(self.dns_name, 2)
        row2.addWidget(dns_btn)
        row2.addSpacing(18)
        row2.addWidget(QLabel("rDNS:"))
        row2.addWidget(self.rdns_ip, 2)
        row2.addWidget(rdns_btn)
        l.addLayout(row2)

        return w

    def tab_web(self) -> QWidget:
        w = QWidget()
        l = QVBoxLayout(w)

        row = QHBoxLayout()
        self.web_url = QLineEdit("https://example.com")
        headers_btn = QPushButton("Headers")
        headers_btn.clicked.connect(self.do_headers)
        robots_btn = QPushButton("robots.txt + sitemap")
        robots_btn.clicked.connect(self.do_robots)

        row.addWidget(QLabel("URL:"))
        row.addWidget(self.web_url, 3)
        row.addWidget(headers_btn)
        row.addWidget(robots_btn)
        l.addLayout(row)

        return w

    def tab_files(self) -> QWidget:
        w = QWidget()
        l = QVBoxLayout(w)

        row = QHBoxLayout()
        self.file_path = QLineEdit("/etc/hosts")
        self.file_algo = QComboBox()
        self.file_algo.addItems(["sha256", "sha1", "md5"])
        hash_btn = QPushButton("Hash")
        hash_btn.clicked.connect(self.do_hash)

        row.addWidget(QLabel("File:"))
        row.addWidget(self.file_path, 3)
        row.addWidget(QLabel("Algo:"))
        row.addWidget(self.file_algo)
        row.addWidget(hash_btn)
        l.addLayout(row)

        row2 = QHBoxLayout()
        self.expected_hash = QLineEdit("")
        verify_btn = QPushButton("Verify")
        verify_btn.clicked.connect(self.do_verify)

        row2.addWidget(QLabel("Expected:"))
        row2.addWidget(self.expected_hash, 4)
        row2.addWidget(verify_btn)
        l.addLayout(row2)

        return w

    def tab_logs(self) -> QWidget:
        w = QWidget()
        l = QVBoxLayout(w)

        row = QHBoxLayout()
        self.log_path = QLineEdit("/var/log/auth.log")
        auth_btn = QPushButton("Triage Auth Log")
        auth_btn.clicked.connect(self.do_auth_log)

        row.addWidget(QLabel("Path:"))
        row.addWidget(self.log_path, 4)
        row.addWidget(auth_btn)
        l.addLayout(row)

        note = QLabel("Note: /var/log/auth.log (Mint) or /var/log/secure (RHEL). Root may be required.")
        note.setStyleSheet("color: #666;")
        l.addWidget(note)

        return w

    def tab_hygiene(self) -> QWidget:
        w = QWidget()
        l = QVBoxLayout(w)
        btn = QPushButton("Run Snapshot")
        btn.clicked.connect(self.do_snapshot)
        l.addWidget(btn, alignment=Qt.AlignLeft)
        return w

    def do_scan(self):
        host = self.net_host.text().strip()
        ports = parse_ports(self.net_ports.text().strip())
        res = net.tcp_connect_scan(host, ports)
        self.log(f"[SCAN] {res.host} ({res.ip}) open: {res.open_ports}")

    def do_dns(self):
        name = self.dns_name.text().strip()
        info = net.dns_lookup(name)
        self.log(f"[DNS] {info}")

    def do_rdns(self):
        ip = self.rdns_ip.text().strip()
        info = net.reverse_dns(ip)
        self.log(f"[rDNS] {info}")

    def do_headers(self):
        url = self.web_url.text().strip()
        info = web.fetch_headers(url)
        self.log(f"[HEADERS] {info['final_url']} status={info['status']}")
        for k, v in info["headers"].items():
            self.log(f"  {k}: {v}")

    def do_robots(self):
        url = self.web_url.text().strip()
        info = web.discover_robots_and_sitemap(url)
        self.log(f"[ROBOTS] {info['robots_url']} status={info['robots_status']}")
        if info["sitemaps"]:
            for s in info["sitemaps"]:
                self.log(f"  sitemap: {s}")

    def do_hash(self):
        path = self.file_path.text().strip()
        algo = self.file_algo.currentText()
        h = fileops.file_hash(path, algo=algo)
        self.log(f"[HASH] {algo} {path} = {h}")

    def do_verify(self):
        path = self.file_path.text().strip()
        algo = self.file_algo.currentText()
        expected = self.expected_hash.text().strip()
        if not expected:
            self.log("[VERIFY] Please paste an expected hash value first.")
            return
        res = fileops.verify_file_hash(path, expected, algo=algo)
        self.log(f"[VERIFY] ok={res['ok']} actual={res['actual']} expected={res['expected']}")

    def do_auth_log(self):
        path = self.log_path.text().strip()
        try:
            info = logs.triage_auth_log(path)
        except FileNotFoundError:
            info = logs.triage_auth_log("/var/log/secure")
        self.log(f"[AUTH] {info}")

    def do_snapshot(self):
        info = hygiene.snapshot()
        self.log(f"[SNAPSHOT] root={info['root']}")
        self.log(info["kernel"] or "")
        self.log(info["listening"] or "")
        if info.get("notes"):
            for n in info["notes"]:
                self.log(f"NOTE: {n}")

def run():
    app = QApplication([])
    w = MainWindow()
    w.show()
    app.exec()
