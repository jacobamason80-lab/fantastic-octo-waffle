from __future__ import annotations
from .utils import run_cmd, is_root

def snapshot() -> dict:
    data = {"root": is_root(), "kernel": None, "users": None, "listening": None, "services": None, "notes": []}

    rc, out, err = run_cmd(["uname", "-a"])
    data["kernel"] = out if rc == 0 else err

    rc, out, err = run_cmd(["bash", "-lc", "cut -d: -f1 /etc/passwd | head -n 50"])
    data["users"] = out if rc == 0 else err

    rc, out, err = run_cmd(["bash", "-lc", "ss -lntup 2>/dev/null | head -n 80 || netstat -lntup 2>/dev/null | head -n 80"])
    data["listening"] = out if rc == 0 else err

    rc, out, err = run_cmd(["bash", "-lc", "systemctl --no-pager --type=service --state=running 2>/dev/null | head -n 80 || service --status-all 2>/dev/null | head -n 80"])
    data["services"] = out if rc == 0 else err

    if not data["root"]:
        data["notes"].append("Run as root for fuller visibility (some commands may be limited).")

    return data
