from __future__ import annotations
import socket
import subprocess

def is_root() -> bool:
    try:
        import os
        return os.geteuid() == 0
    except Exception:
        return False

def run_cmd(cmd: list[str], timeout: int = 20) -> tuple[int, str, str]:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()

def resolve_host(target: str) -> str:
    try:
        socket.inet_aton(target)
        return target
    except OSError:
        return socket.gethostbyname(target)

def parse_ports(ports: str) -> list[int]:
    result: list[int] = []
    for part in ports.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            if start > end:
                start, end = end, start
            result.extend(range(start, end + 1))
        else:
            result.append(int(part))
    clean = sorted({p for p in result if 1 <= p <= 65535})
    return clean
