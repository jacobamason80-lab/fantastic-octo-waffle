from __future__ import annotations
import typer
from rich import print
from rich.table import Table
from rich.console import Console

from .utils import parse_ports, run_cmd
from . import net, web, fileops, logs, hygiene
from .version import __version__

app = typer.Typer(add_completion=False, help="Linux Cyber Tool Box (authorized use only).")
console = Console()

net_app = typer.Typer(help="Network tools")
web_app = typer.Typer(help="Web tools")
file_app = typer.Typer(help="File hashing tools")
logs_app = typer.Typer(help="Log triage tools")
hyg_app = typer.Typer(help="System hygiene tools")

app.add_typer(net_app, name="net")
app.add_typer(web_app, name="web")
app.add_typer(file_app, name="file")
app.add_typer(logs_app, name="logs")
app.add_typer(hyg_app, name="hygiene")

@app.callback()
def _version(ctx: typer.Context, version: bool = typer.Option(False, "--version", help="Show version and exit.")):
    if version:
        print(__version__)
        raise typer.Exit()

@net_app.command("scan")
def scan(host: str, ports: str = typer.Option("22,80,443", help="Ports: '22,80,443' or '1-1024'")):
    plist = parse_ports(ports)
    res = net.tcp_connect_scan(host, plist)
    print(f"[bold]Host:[/bold] {res.host}  [bold]IP:[/bold] {res.ip}")
    t = Table(title="TCP Connect Scan")
    t.add_column("Open Ports")
    t.add_column("Count", justify="right")
    t.add_row(", ".join(map(str, res.open_ports)) if res.open_ports else "-", str(len(res.open_ports)))
    console.print(t)

@net_app.command("dns")
def dns(name: str):
    info = net.dns_lookup(name)
    if info["error"]:
        print(f"[red]Error:[/red] {info['error']}")
        raise typer.Exit(code=1)
    print(f"[bold]Name:[/bold] {info['name']}")
    print(f"[bold]Aliases:[/bold] {info['aliases']}")
    print(f"[bold]A Records:[/bold] {info['a_records']}")

@net_app.command("rdns")
def rdns(ip: str):
    info = net.reverse_dns(ip)
    if info["error"]:
        print(f"[red]Error:[/red] {info['error']}")
        raise typer.Exit(code=1)
    print(f"[bold]IP:[/bold] {info['ip']}")
    print(f"[bold]PTR:[/bold] {info['ptr']}")
    print(f"[bold]Aliases:[/bold] {info['aliases']}")

@net_app.command("ping")
def ping(host: str, count: int = 4):
    rc, out, err = run_cmd(["bash", "-lc", f"ping -c {count} {host}"])
    print(out if rc == 0 else err)

@net_app.command("trace")
def trace(host: str):
    rc, out, err = run_cmd(["bash", "-lc", f"traceroute {host} 2>/dev/null || tracepath {host}"])
    print(out if rc == 0 else err)

@web_app.command("headers")
def headers(url: str):
    info = web.fetch_headers(url)
    print(f"[bold]Final URL:[/bold] {info['final_url']}")
    print(f"[bold]Status:[/bold] {info['status']}")
    for k, v in info["headers"].items():
        print(f"{k}: {v}")

@web_app.command("robots")
def robots(url: str):
    info = web.discover_robots_and_sitemap(url)
    print(f"[bold]robots.txt:[/bold] {info['robots_url']}  (status {info['robots_status']})")
    if info["sitemaps"]:
        print("[bold]Sitemaps:[/bold]")
        for s in info["sitemaps"]:
            print(f" - {s}")
    else:
        print("[yellow]No sitemap entries discovered.[/yellow]")

@file_app.command("hash")
def hash_file(path: str, algo: str = typer.Option("sha256", help="md5|sha1|sha256")):
    h = fileops.file_hash(path, algo=algo)
    print(f"[bold]{algo}:[/bold] {h}")

@file_app.command("verify")
def verify_file(path: str, expected: str, algo: str = typer.Option("sha256", help="md5|sha1|sha256")):
    res = fileops.verify_file_hash(path, expected, algo=algo)
    print("[green]OK[/green] hash matches." if res["ok"] else "[red]FAIL[/red] hash mismatch.")
    print(f"[bold]Expected:[/bold] {res['expected']}")
    print(f"[bold]Actual:[/bold]   {res['actual']}")

@logs_app.command("auth")
def auth(path: str = typer.Option("/var/log/auth.log", help="Auth log path (/var/log/auth.log or /var/log/secure)")):
    try:
        info = logs.triage_auth_log(path)
    except FileNotFoundError:
        info = logs.triage_auth_log("/var/log/secure")

    print(f"[bold]Log:[/bold] {info['path']}")
    print(f"[bold]Failed login matches:[/bold] {info['total_failed_matches']}")

    t = Table(title="Top IPs")
    t.add_column("IP")
    t.add_column("Count", justify="right")
    for ip, c in info["top_ips"]:
        t.add_row(ip, str(c))
    console.print(t)

    u = Table(title="Top Users")
    u.add_column("User")
    u.add_column("Count", justify="right")
    for user, c in info["top_users"]:
        u.add_row(user, str(c))
    console.print(u)

@hyg_app.command("snapshot")
def snap():
    info = hygiene.snapshot()
    print(f"[bold]Root:[/bold] {info['root']}")
    print(f"\n[bold]Kernel:[/bold]\n{info['kernel']}")
    print(f"\n[bold]Users (first 50):[/bold]\n{info['users']}")
    print(f"\n[bold]Listening ports:[/bold]\n{info['listening']}")
    print(f"\n[bold]Services:[/bold]\n{info['services']}")
    if info["notes"]:
        print("\n[yellow]Notes:[/yellow]")
        for n in info["notes"]:
            print(f" - {n}")

def main():
    app()

if __name__ == "__main__":
    main()
