from __future__ import annotations
import socket
from dataclasses import dataclass
from typing import List
from .utils import resolve_host

@dataclass
class ScanResult:
    host: str
    ip: str
    open_ports: List[int]
    closed_ports: List[int]

def tcp_connect_scan(host: str, ports: list[int], timeout: float = 0.35) -> ScanResult:
    ip = resolve_host(host)
    open_ports: list[int] = []
    closed_ports: list[int] = []
    for port in ports:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        try:
            rc = s.connect_ex((ip, port))
            if rc == 0:
                open_ports.append(port)
            else:
                closed_ports.append(port)
        except Exception:
            closed_ports.append(port)
        finally:
            try: s.close()
            except Exception: pass
    return ScanResult(host=host, ip=ip, open_ports=open_ports, closed_ports=closed_ports)

def dns_lookup(name: str) -> dict:
    info = {"name": name, "a_records": [], "aliases": [], "error": None}
    try:
        host, aliases, ips = socket.gethostbyname_ex(name)
        info["name"] = host
        info["aliases"] = aliases
        info["a_records"] = ips
    except Exception as e:
        info["error"] = str(e)
    return info

def reverse_dns(ip: str) -> dict:
    info = {"ip": ip, "ptr": None, "aliases": [], "error": None}
    try:
        host, aliases, _ = socket.gethostbyaddr(ip)
        info["ptr"] = host
        info["aliases"] = aliases
    except Exception as e:
        info["error"] = str(e)
    return info
