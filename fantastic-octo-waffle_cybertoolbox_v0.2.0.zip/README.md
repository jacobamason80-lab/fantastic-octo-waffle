# Fantastic Octo Waffle — Cyber Toolbox (Linux Mint)

A polished **Linux Mint** portfolio project: a defensive cyber utility toolkit with both:
- **CLI** (`toolbox`)
- **GUI** (`cyber-toolbox`) with tabs (Network/Web/File/Logs/Hygiene)

Authorized use only.

## Quick start (dev)
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m toolbox --help
python -m toolbox.gui_main
```

## Build a Mint .deb
```bash
sudo apt install -y dpkg-dev
./build.sh
sudo apt install ./linux-cyber-toolbox_{VERSION}_all.deb
```

## Release workflow
```bash
./release.sh minor   # example: 0.2.0 -> 0.3.0
```

## Legal
Use only on systems you own or where you have explicit permission.
